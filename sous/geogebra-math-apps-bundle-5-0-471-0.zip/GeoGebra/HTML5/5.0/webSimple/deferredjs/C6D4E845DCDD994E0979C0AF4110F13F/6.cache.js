$wnd.webSimple.runAsyncCallback6('WMg(Mi)(6);\n//# sourceURL=webSimple-6.js\n')
